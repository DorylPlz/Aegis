<?php


	function get_date(){
		return date('Y-m-d');



	}
	
	function get_date_hour(){
		return date('Y-m-d-hi-a');



	}
	function get_date_hour_s(){
		return date('Y-m-d-hi-a-s');



	}

?>