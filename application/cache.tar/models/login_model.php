<?php

class login_model extends CI_Model {
    public function __construct()
    {
        // Call the CI_Model constructor
        parent::__construct();
    }

	function new_user($registro, $registroEsp){
		$this->load->database();

		$this->db->insert('usuario',$registro);
		$this->db->insert('esp_taken',$registroEsp);
	}



}


?>