
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.8.1, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/factions-blanco-logo-156x61.png'); ?>" type="image/x-icon">
  <meta name="description" content="">
  <title>Nosotros - Legión Aegis</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/web/assets/mobirise-icons/mobirise-icons.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/tether/tether.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap-grid.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap-reboot.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/socicon/css/styles.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/dropdown/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/theme/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/mobirise/css/mbr-additional.css'); ?>" type="text/css">
  
  
  
</head>
<body>


<section class="engine"><a href=""></a></section><section class="mbr-section content5 cid-r0ROnkWOud mbr-parallax-background" id="content5-1w">

    

    

    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center mbr-bold mbr-white pb-3 mbr-fonts-style display-1"><em>
                    Quienes somos</em></h2>
                <h3 class="mbr-section-subtitle align-center mbr-light mbr-white pb-3 mbr-fonts-style display-5">Conocenos</h3>
                
                
            </div>
        </div>
    </div>
</section>

<section class="testimonials3 cid-r0VcCEsaRH" id="testimonials3-21">

    

    

    <div class="container">
        <div class="media-container-row">
            <div class="media-content px-3 align-self-center mbr-white py-2">
                <p class="mbr-text testimonial-text mbr-fonts-style display-7">&nbsp;<br><br>Clan Legion Aegis es un grupo de simulación militar latinoamericano de ARMA 3 previamente conocido como "Clan Factions", creado en el 2015 en Chile y cuenta con miembros de diversas nacionalidades.
<br>El objetivo del Clan Legion Aegis es ofrecer un espacio de diversión para todos sus miembros teniendo siempre presente los principios del respeto entre compañeros, trabajo en equipo, motivación, participación, compromiso, interés por aprender y disciplina.
<br>
<br>Si quieres ser parte de un equipo organizado y capaz de afrontar las situaciones más complicadas en el campo de batalla y cumplir con el objetivo Clan Legion Aegis es tu lugar.
<br>
<br>
<br>Clan Legion Aegis dispone de una estructura administrativa y de gestión preparada para dar respuesta a las necesidades y requerimientos de todos los miembros, dispuesta a buscar las mejores soluciones y ofrecer una experiencia de juego lo más agradable y satisfactoria para todos.
<br>¡Unete a la Legion!</p>
                <p class="mbr-author-name pt-4 mb-2 mbr-fonts-style display-7" style="font-color: #efefef;"><em>Legion Aegis</em></p>
                <p class="mbr-author-desc mbr-fonts-style display-7">2015</p>
            </div>

            <div class="mbr-figure pl-lg-5" style="width: 130%;">
              <img src="<?php echo base_url('assets/images/featured-4-1046x588.jpg'); ?>" alt="" title="">
            </div>
        </div>
    </div>
</section>




  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/theme/js/script.js"></script>
  
